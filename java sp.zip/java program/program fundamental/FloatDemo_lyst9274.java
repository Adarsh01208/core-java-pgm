class FloatDemo
{
	public static void main(String[] args)
	{
		float no=10.2f;
		System.out.println(no);

		double no2=20.2;
		System.out.println(no2);
	}
}