class BinaryNoSystem
{
	public static void main(String[] args)
	{
		int a=0B1112;
		System.out.println(a);
	}
}