class Conversion2
{
	public static void main(String[] args)
	{
		System.out.println(Integer.toBinaryString(123));
		System.out.println(Integer.toOctalString(123));
		System.out.println(Integer.toHexString(123));
	}
}