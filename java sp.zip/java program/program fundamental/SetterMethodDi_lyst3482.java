class A
{
	
}
class B
{
	int bb;
	public void setBb(A a)
	{

	}
}
class SetterMethodDi
{
	public static void main(String args)
	{
		A ob2=new A();
		B ob1=new B();
		ob1.setBb(ob2);
	}
}