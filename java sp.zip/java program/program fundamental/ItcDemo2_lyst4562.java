class ItcDemo2
{
	public static void main(String[] args)
	{
		byte no1=10;
		long no2=100;
		long res=no1+no2;
	}
}