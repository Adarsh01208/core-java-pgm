class OctalNoSystem
{
	public static void main(String[] args)
	{
		int a=0100;
		System.out.println(a);
	}
}