class HexaDecimalNoSystem
{
	public static void main(String[] args)
	{
		int a=0x1345460;
		System.out.println(a);
	}
}