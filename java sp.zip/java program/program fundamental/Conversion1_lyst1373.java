class Conversion1
{
	public static void main(String[] args)
	{
		//String no1="101";
		//int res=Integer.parseInt(no1, 2);
		//System.out.println(res);
		System.out.println(Integer.parseInt("101", 2));

		int no2=0b101;
		System.out.println(no2);
	}
}