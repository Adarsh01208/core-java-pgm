class VariablesDemo1
{
	int d=300;		//instance variable
	static int e=500;	//static variable
	void sum()
	{
		int a=100;	//local variable
	}
	void mul()
	{
		int b=200;	//local variable
		int c;		//local variable
	}
	
	static void divide()
	{
		int rollno=101;	//local variable
	}
}