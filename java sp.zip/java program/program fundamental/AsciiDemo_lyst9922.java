class AsciiDemo
{
	public static void main(String[] args)
	{
		for(int i=0; i<=300; i++)
		{
			System.out.println( (char)i +" : "+i );
		}
	}
}